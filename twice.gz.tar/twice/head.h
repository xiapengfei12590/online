#ifndef __HEAD_H__
#define __HEAD_H__

struct info
{
	int order;
	char id[128];
	int power;
	char data[256];
}unit; 

struct all
{
	char id[128];
	char name[128];
	char sex;
	int age;
	float salary;
	char telephone[12];
};
#endif
