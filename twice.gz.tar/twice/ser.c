#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <sqlite3.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include "./head.h"
#define ADDR "192.168.10.28"
#define EMSG(msg) do{\
	fprintf(stderr,"__%d__",__LINE__);\
	perror(msg);\
}while(0)

typedef void (*sighandler_t)(int);
void handler(int sig)
{
	while(waitpid(-1, NULL, WNOHANG) > 0);
	printf("got it\n");
}
sqlite3* tables_init(void);
int  sign_up(int fd,sqlite3* db);
int sign_in(int fd,sqlite3* db);
void mysend(int fd);
void search(int fd,sqlite3 *db);
int insert(int fd,sqlite3 *db);
int del(int fd,sqlite3 *db);
int my_update(int fd,sqlite3 *db);
int main(int argc, const char *argv[])
{
	sighandler_t s = signal(SIGCHLD, handler);
	if(SIG_ERR == s)
	{
		EMSG("signal");
		return -1;
	}

	sqlite3 *db=tables_init();
	if(db==NULL)
	{
		printf("sqlite3 error\n");
		return -1;
	}

	int sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd<0)
	{
		EMSG("socket");
		return -1;
	}

	int reuse = 1;
	if(setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) < 0)
	{
		EMSG("setsockopt");
		return -1;
	}

	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_addr.s_addr=inet_addr(ADDR);
	sin.sin_port=htons(8888);

	if(bind(sfd,(struct sockaddr*)&sin,sizeof(sin))<0)
	{
		EMSG("bind");
		return -1;
	}
	printf("bind\n");

	listen(sfd,10);

	int newfd,res;
	struct sockaddr_in cin;
	socklen_t len=sizeof(cin);
	int flag=0;
	while(1)
	{
		newfd=accept(sfd,(struct sockaddr*)&cin,&len);
		if(newfd<0)
		{
			if(errno!=9)
			{
				EMSG("accept");
				printf("errno=%d\n",errno);
			}
		}
		else if(newfd>0)
		{
			printf("[%s | %d]newfd = %d 连接成功\n",inet_ntoa(cin.sin_addr), ntohs(cin.sin_port), newfd);
			if(fork()==0)
			{
				close(sfd);
				while(1)
				{
					res=recv(newfd,&unit,sizeof(unit),0);
					if(res>0)
					{
						printf("order=%d\n",unit.order);
						switch(unit.order)
						{
						case 1:
							//注册
							flag=sign_up(newfd,db);
							break;
						case 2:
							//登录
							flag=sign_in(newfd,db);
							break;
						case 3:
							//查询
							search(newfd,db);
							break;
						case 4:
							flag=insert(newfd,db);
							break;
						case 5:
							flag=del(newfd,db);
							//删除
							break;
						case 6:
							flag=my_update(newfd,db);
							break;
						default:
							break;
						}
						if(flag==1)
						{
							mysend(newfd);
							flag=0;
						}
					}
					else if(res==0)
					{
						printf("[%s | %d]newfd = %d 客户端退出\n",inet_ntoa(cin.sin_addr), ntohs(cin.sin_port), newfd);
						return 0;
					}
					else
					{
						EMSG("recv");
						printf("sdfghjkhgfd\n");
						return -1;
					}
				}
			}
			close(newfd);
		}
	}
	return 0;
}
sqlite3 *tables_init(void)
{
	sqlite3 *db=NULL;
	if(sqlite3_open("./base.db",&db)!=SQLITE_OK)
	{
		fprintf(stderr,"__%d__  sqlite3_open:%s\n",__LINE__,sqlite3_errmsg(db));
		return NULL;
	}
	char *emsg;
	char sql[300]="create table if not exists users (uid char primary key,\
				   passwd char,power int)";
	if(sqlite3_exec(db,sql,NULL,NULL,&emsg)!=0)
	{
		fprintf(stderr,"__%d__  sqlite3 create table:%s\n",__LINE__,emsg);
		return NULL;
	}
	strcpy(sql,"create table if not exists info (uid char primary key,\
		name char,sex char,age int,salary float,telephone char);");
	if(sqlite3_exec(db,sql,NULL,NULL,&emsg)!=0)
	{
		fprintf(stderr,"__%d__  sqlite3 create table:%s\n",__LINE__,emsg);
		return NULL;
	}
	printf("tables create success\n");
	return db;
}
int sign_up(int fd,sqlite3* db)
{
	char sql[2700];
	char *emsg=NULL;
	bzero(sql,sizeof(sql));
	sprintf(sql,"insert into users values (\"%s\",\"%s\",%d);",unit.id,unit.data,unit.power);
	if(sqlite3_exec(db,sql,NULL,NULL,&emsg)!=0)
	{
		if(sqlite3_errcode(db)!=19)
		{
			fprintf(stderr,"__%d__,sqlite3_exec insert:%s",__LINE__,emsg);
			strcpy(unit.data,"base busy!");
			return 1;
		}
		else if(sqlite3_errcode(db)==19)
		{
			printf("errcode:%d\n",sqlite3_errcode(db));
			bzero(unit.data,sizeof(unit.data));
			strcpy(unit.data,"用户已存在");
		}
	}
	else
	{
		bzero(unit.data,sizeof(unit.data));
		strcpy(unit.data,"注册成功");
		printf("插入成功\n");
	}
	return 1;
}
int  sign_in(int fd,sqlite3* db)
{
	char sql[300];
	char *errmsg=NULL;
	int row,clown;
	char **pres;
	sprintf(sql,"select * from users where uid=\"%s\" ",unit.id);	
	if(sqlite3_get_table(db,sql,&pres,&row,&clown,&errmsg)!=0)
	{
		fprintf(stderr,"sqlite3_get_table error:%s ___%d__",errmsg,__LINE__);
		strcpy(unit.data,"base busy!");
		return 1;
	}
	if(row*clown==0)
	{
		strcpy(unit.data,"该用户不存在");
		unit.power=0;
	}
	else
	{
		if(strcmp(pres[4],unit.data)==0)
		{
			if(strcmp(pres[5],"0")==0)
			{
				unit.power=1;
				strcpy(unit.data,"登录成功");
			}
			else 
			{
				unit.power=2;
				strcpy(unit.data,"管理员登录成功");
			}
		}
		else
		{
			unit.power=0;
			strcpy(unit.data,"密码错误");
		}
	}
	sqlite3_free_table(pres);
	return 1;
}
void mysend(int fd)
{

	if(send(fd,&unit,sizeof(unit),0)<0)
	{
		EMSG("mysend");
		return;
	}
	return;
}
void search(int fd,sqlite3 *db)
{
	char sql[256];
	char *errmsg=NULL;
	int row,cloum;
	char **pres=NULL;
	//获取当前用户权限
	sprintf(sql,"select * from users where uid=\"%s\";",unit.id);
	puts(sql);
	if(sqlite3_get_table(db,sql,&pres,&row,&cloum,&errmsg)!=0)
	{
		fprintf(stderr,"sqlite3_get_table:%s __%d__",errmsg,__LINE__);
		return;
	}
	bzero(sql,sizeof(sql));
	printf("power:%s\n",pres[5]);
	if(cloum*row==0)
	{
		strcpy(unit.data,"非法访问");
		send(fd,&unit,sizeof(unit),0);
		return;
	}


	if(strcmp(pres[5],"0")==0)
	{
		//普通用户
		sprintf(sql,"select uid,name,sex,age from info;");
		sqlite3_free_table(pres);
		if(sqlite3_get_table(db,sql,&pres,&row,&cloum,&errmsg)!=0)
		{
			fprintf(stderr,"sqlite3_get_table:%s __%d__",errmsg,__LINE__);
			return;
		}
		if(cloum*row==0)
		{
			bzero(unit.data,sizeof(unit.data));
			strcpy(unit.data,"no mssage!!!!");
		}
		else
		{
			bzero(unit.data,sizeof(unit.data));
			unit.order=0;
			unit.power=(1+row)*cloum;
			send(fd,&unit,sizeof(unit),0);
			while(unit.power>unit.order)
			{
				//printf("order:%d\n",unit.order);
				//printf("power:%d\n",unit.power);
				//printf("%s\n",pres[unit.order]);
				strcat(unit.data,pres[unit.order]);
				strcat(unit.data,"\t");
				if(unit.order%cloum==3)
				{
					strcat(unit.data,"\n");
				}
				send(fd,&unit,sizeof(unit),0);
				bzero(unit.data,sizeof(unit.data));
				unit.order++;
			}
		}
		send(fd,&unit,sizeof(unit),0);
	}
	else
	{
		//管理员用户
		strcpy(sql,"select * from info;");
		sqlite3_free_table(pres);
		if(sqlite3_get_table(db,sql,&pres,&row,&cloum,&errmsg)!=0)
		{
			fprintf(stderr,"sqlite3_get_table:%s __%d__",errmsg,__LINE__);
			return;
		}
		if(cloum*row==0)
		{
			bzero(unit.data,sizeof(unit.data));
			strcpy(unit.data,"no mssage!!!!");
		}
		else
		{
			bzero(unit.data,sizeof(unit.data));
			unit.order=0;
			unit.power=(1+row)*cloum;
			send(fd,&unit,sizeof(unit),0);
			while(unit.power>unit.order)
			{
				//printf("order:%d\n",unit.order);
				//printf("power:%d\n",unit.power);
				//printf("%s\n",pres[unit.order]);
				strcat(unit.data,pres[unit.order]);
				strcat(unit.data,"\t");
				if(unit.order%cloum==5)
				{
					strcat(unit.data,"\n");
				}
				send(fd,&unit,sizeof(unit),0);
				bzero(unit.data,sizeof(unit.data));
				unit.order++;
			}

		}
		send(fd,&unit,sizeof(unit),0);
	}
}
int  insert(int fd,sqlite3 *db)
{
	struct all ins;
	char sql[512]={0};
	char *errmsg;
	recv(fd,&ins,sizeof(ins),0);
	sprintf(sql,"insert into info values (\"%s\",\"%s\",\"%c\",%d,%f,\"%s\")",\
			ins.id ,ins.name ,ins.sex ,ins.age ,ins.salary ,ins.telephone );
	puts(sql);
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0)
	{
		if(sqlite3_errcode(db)!=19)
		{
			fprintf(stderr,"__%d__,sqlite3_exec insert:%s",__LINE__,errmsg);
			strcpy(unit.data,"base busy!");
			return 1;
		}
		else if(sqlite3_errcode(db)==19)
		{
			printf("errcode:%d\n",sqlite3_errcode(db));
			bzero(unit.data,sizeof(unit.data));
			strcpy(unit.data,"用户已存在");
		}

	}
	else
	{
		bzero(unit.data,sizeof(unit.data));
		strcpy(unit.data,"添加成功");
		printf("添加成功\n");
	}
	return 1;
}

int del(int fd,sqlite3 *db)
{
	//删除info和users的信息
	char sql[600];
	char *errmsg=NULL;
	int row,cloum;
	char **pres;
	sprintf(sql,"select * from info where uid=\"%s\";",unit.data);
	if(sqlite3_get_table(db,sql,&pres,&row,&cloum,&errmsg)!=0)
	{
		printf("errcode:%d\n",sqlite3_errcode(db));
		fprintf(stderr,"sqlite3_exec select:%s  __%d__\n",errmsg,__LINE__);
		strcpy(unit.data,"base busy!!");
		return 1;
	}
	if(row*cloum!=0)
	{
		sprintf(sql,"delete from info where uid=\"%s\";",unit.data);
		if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0)
		{
			printf("errcode:%d\n",sqlite3_errcode(db));
			fprintf(stderr,"sqlite3_exec delete:%s  __%d__\n",errmsg,__LINE__);
			strcpy(unit.data,"base busy!!");
			return 1;
		}
		//	puts(sql);
		bzero(sql,sizeof(sql));
		sprintf(sql,"delete from users where uid=\"%s\";",unit.data);
		if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0)
		{
			fprintf(stderr,"sqlite3_exec delete:%s  __%d__\n",errmsg,__LINE__);
			strcpy(unit.data,"base busy!!");
			return 1;
		}
		strcpy(unit.data,"删除成功");
	}
	else
	{
		strcpy(unit.data,"该用户不存在");
	}
	return 1;
}
int my_update(int fd,sqlite3 *db)
{
	struct all ins;
	recv(fd,&ins,sizeof(ins),0);
	char *errmsg=NULL;
	char sql[512];
	char **pres=NULL;
	int row,cloum;
	sprintf(sql,"select * from info where uid=\"%s\";",ins.id);
	if(sqlite3_get_table(db,sql,&pres,&row,&cloum,&errmsg)!=0)
	{
		printf("errcode:%d\n",sqlite3_errcode(db));
		fprintf(stderr,"sqlite3_exec select:%s  __%d__\n",errmsg,__LINE__);
		strcpy(unit.data,"base busy!!");
		return 1;
	}

	if(cloum)
	{
		sprintf(sql,"update info set name=\"%s\",sex=\"%c\",age=%d,salary=%f,telephone=\"%s\" where uid=\"%s\"",\
				ins.name,ins.sex,ins.age,ins.salary,ins.telephone,ins.id);
		puts(sql);
		if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0)
		{
			strcpy(unit.data,"更新失败，请重试");
			fprintf(stderr,"sqlite3_exec update:%s __%d__",errmsg,__LINE__);
			printf("errcode:%d\n",sqlite3_errcode(db));
		}
		else
		{
			strcpy(unit.data,"更新成功");
		}
	}
	else
		strcpy(unit.data,"用户不存在");
	return 1;
}
