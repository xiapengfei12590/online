#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include "./head.h"
#define EMSG(msg) do{\
	fprintf(stderr,"__%d__",__LINE__);\
	perror(msg);\
}while(0)


#define ADDR "192.168.10.28"
int sign_up(void);
int sign_in(void);
void commen(int fd);
void uncommen(int fd);
void search(int fd);
void insert(int fd); 
int del(void);
void my_update(int fd);
int main(int argc, const char *argv[])
{
	int fd=socket(AF_INET,SOCK_STREAM,0);
	if(fd<0)
	{
		EMSG("socket");
		return -1;
	}

	struct sockaddr_in cin;
	cin.sin_addr.s_addr=inet_addr(ADDR);
	cin.sin_family=AF_INET;
	cin.sin_port=htons(8888);


	if(connect(fd,(struct sockaddr*)&cin,sizeof(cin))<0)
	{
		EMSG("connect");
		return -1;
	}
	printf("connect success\n");

	char choice;
	int flag;
	int cmd;
RD:
	while(1)
	{
		system("clear");
		printf("****************\n");
		printf("*****1.注册*****\n");
		printf("*****2.登录*****\n");
		printf("*****3.退出*****\n");
		printf("****************\n");
		scanf("%c",&choice);
		while(getchar()!=10);
		switch(choice)
		{
		case '1':
			//注册
			flag=sign_up();
			break;
		case '2':
			//登录
			flag=sign_in();
			break;
		case '3':
			return 0;
		default:
			printf("输入有误，请重新输入\n");
			break;
		}
		if(flag==1)
		{
			send(fd,&unit,sizeof(unit),0);
			recv(fd,&unit,sizeof(unit),0);
			printf("%s\n",unit.data);
			flag=0;
		}
		if(choice=='2')
		{
			cmd=unit.power;
			printf("cmd=%d\n",unit.power);
			if(cmd==1)
				commen(fd);
			else if(cmd==2)
				uncommen(fd);
		goto RD;
		}
		printf("输入回车以确认\n");
		choice=getchar();
		while((getchar()!=10));
	}


	return 0;
}
int sign_up(void)
{
	bzero(unit.data,sizeof(unit.data));
	bzero(unit.id,sizeof(unit.id));
	char tem[256];
	bzero(tem,sizeof(tem));
	unit.order=1;
	printf("请输入账号\n");
	scanf("%s",unit.id);
	printf("请输密码\n");
	scanf("%s",unit.data);
	printf("请输入密匙,不清楚则输入任意字符\n");
	scanf("%s",tem);
	if(strcmp(tem,"order")==0)
	{
		unit.power=1;
	}
	else
	{
		unit.power=0;
	}
	return 1;

}
int sign_in(void)
{
	unit.order=2;
	bzero(unit.data,sizeof(unit.data));
	bzero(unit.id,sizeof(unit.id));
	printf("请输入账号\n");
	scanf("%s",unit.id);
	printf("请输密码\n");
	scanf("%s",unit.data);
	printf("%s\n",unit.data);
	return 1;

}
void commen(int fd)
{
	char choice;
	int flag=0;
	while(1)
	{
		system("clear");
		printf("****************************\n");
		printf("*1.查询  2.修改密码  3.退出*\n");
		printf("****************************\n");
		printf("*********请输入选择*********\n");
		choice=getchar();
		while(getchar()!=10);
		switch(choice)
		{
		case '1':
			//查找
			search(fd);
			break;
		case '2':
			printf("未实装\n");
			break;
		case '3':
			return;
		default:
			printf("输入有误，请重新输入\n");
			break;
		}
		if(flag==1)
		{
			send(fd,&unit,sizeof(unit),0);
			recv(fd,&unit,sizeof(unit),0);
			printf("%s\n",unit.data);
			flag=0;
		}
		printf("输入任意字符以清屏\n");
		getchar();
		while(getchar()!=10);
	}

}
void uncommen(int fd)
{
	int flag=0;
	char choice;
	while(1)
	{
		system("clear");
		printf("------------------\n");
		printf("|    1.查询      |\n");
		printf("|    2.添加      |\n");
		printf("|    3.修改      |\n");
		printf("|    4.删除      |\n");
		printf("|    5.退出      |\n");
		printf("------------------\n");
		printf("*********请输入选择*********\n");
		choice=getchar();
		while(getchar()!=10);
		switch(choice)
		{
		case '1':
			//查询
			search(fd);
			break;
		case '2':
			insert(fd);
			//添加
			break;
		case '3':
			//修改
			my_update(fd);
			break;
		case '4':
			//删除
			flag=del();
			break;
		case '5':
			return;
		default:
			printf("输入有误\n");
			break;
		}
		if(flag==1)
		{
			send(fd,&unit,sizeof(unit),0);
			recv(fd,&unit,sizeof(unit),0);
			printf("%s\n",unit.data);
			flag=0;
		}
		printf("输入任意以清屏\n");
		//getchar();
		while(getchar()!=10);
	}


}
void search(int fd)
{
	unit.order=3;
	printf("id:%s\n",unit.id);
	send(fd,&unit,sizeof(unit),0);
	recv(fd,&unit,sizeof(unit),0);
	//printf("power=%d  order=%d\n",unit.power,unit.order);
	while(unit.power>unit.order)
	{
		recv(fd,&unit,sizeof(unit),0);
	//	printf("power=%d  order=%d\n",unit.power,unit.order);
		printf("%s",unit.data);
	}
	return ;
}
void insert(int fd)
{
	unit.order=4;
	send(fd,&unit,sizeof(unit),0);
 	struct all ins;
	printf("请输入员工id>>>");
	scanf("%s",ins.id);
	printf("请输入员工姓名>>>");
	scanf("%s",ins.name);
ERR1:
	printf("请输入员工性别 m/f >>>");
	scanf("%s",&(ins.sex));
	if(ins.sex!='f'&&ins.sex!='m')
	{
		goto ERR1;
	}
	printf("请输入员工年龄>>>");
	scanf("%d",&(ins.age));
	printf("请输入员工薪资>>>");
	scanf("%f",&(ins.salary));
	printf("请输入员工手机号>>>");
	scanf("%s",ins.telephone);
	send(fd,&ins,sizeof(ins),0);
	recv(fd,&unit,sizeof(unit),0);
	printf("%s\n",unit.data);
}

int del(void)
{
	unit.order=5;
	printf("请输入员工id>>>>");
	bzero(unit.data,sizeof(unit.data));
	scanf("%s",unit.data);
	return 1;
}
void my_update(int fd)
{
	unit.order=6;
	send(fd,&unit,sizeof(unit),0);
	 struct all ins;
	printf("请输入员工id>>>");
	scanf("%s",ins.id);
	printf("请输入员工姓名>>>");
	scanf("%s",ins.name);
ERR1:
	printf("请输入员工性别 m/f >>>");
	scanf("%s",&(ins.sex));
	if(ins.sex!='f'&&ins.sex!='m')
	{
		goto ERR1;
	}
	printf("请输入员工年龄>>>");
	scanf("%d",&(ins.age));
	printf("请输入员工薪资>>>");
	scanf("%f",&(ins.salary));
	printf("请输入员工手机号>>>");
	scanf("%s",ins.telephone);
	send(fd,&ins,sizeof(ins),0);
	recv(fd,&unit,sizeof(unit),0);
	printf("%s\n",unit.data);
}
